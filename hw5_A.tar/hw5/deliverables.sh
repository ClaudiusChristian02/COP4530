# used by bash script submit.sh
COURSE_HOME=cop4530p
ASSIGNMENT=homework5
FILES="hashtbl.h iprouter.cpp iputil.cpp log.txt"
